package org.solarflare.myFirstDBProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyFirstDbProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
